import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;



// User Base Class
abstract class User {
    protected int id;
    protected String username;
    protected String password;
    protected String role;
    protected boolean hasVoted;

    public User(int id, String username, String password, String role, boolean hasVoted) {
        this.id = id;
        this.username = username;
        this.password = password;
        this.role = role;
        this.hasVoted = hasVoted;
    }

    public abstract boolean login(String username, String password);
    public abstract void logout();

    public int getId() { return id; }
    public String getUsername() { return username; }
    public String getRole() { return role; }
    public boolean hasVoted() { return hasVoted; }
}

// Candidate Class
class Candidate {
    private int id;
    private String name;
    private String party;
    private int votes;

    public Candidate(int id, String name, String party, int votes) {
        this.id = id;
        this.name = name;
        this.party = party;
        this.votes = votes;
    }

    public int getId() { return id; }
    public String getName() { return name; }
    public String getParty() { return party; }
    public int getVotes() { return votes; }

    @Override
    public String toString() {
        return name + " (" + party + ")";
    }
}

// Voter Class
class Voter extends User {
    public Voter(int id, String username, String password, boolean hasVoted) {
        super(id, username, password, "voter", hasVoted);
    }

    @Override
    public boolean login(String username, String password) {
        return this.username.equals(username) && this.password.equals(password);
    }

    @Override
    public void logout() {
        System.out.println("Voter logged out");
    }

    public void vote(int candidateId) throws SQLException {
        try (Connection conn = DBConnection.getConnection()) {
            // Record vote
            String sql = "INSERT INTO votes (user_id, candidate_id) VALUES (?, ?)";
            try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setInt(1, this.id);
                pstmt.setInt(2, candidateId);
                pstmt.executeUpdate();
            }

            // Update candidate votes
            sql = "UPDATE candidates SET votes = votes + 1 WHERE id = ?";
            try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setInt(1, candidateId);
                pstmt.executeUpdate();
            }

            // Mark user as voted
            sql = "UPDATE users SET has_voted = TRUE WHERE id = ?";
            try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setInt(1, this.id);
                pstmt.executeUpdate();
            }
            this.hasVoted = true;
        }
    }
}

// Admin Class
class Admin extends User {
    public Admin(int id, String username, String password) {
        super(id, username, password, "admin", false);
    }

    @Override
    public boolean login(String username, String password) {
        return this.username.equals(username) && this.password.equals(password);
    }

    @Override
    public void logout() {
        System.out.println("Admin logged out");
    }
}

// Election Manager
class ElectionManager {
    public static User authenticate(String username, String password) {
        String sql = "SELECT * FROM users WHERE username = ? AND password = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, username);
            pstmt.setString(2, password);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    int id = rs.getInt("id");
                    String role = rs.getString("role");
                    boolean hasVoted = rs.getBoolean("has_voted");

                    if ("admin".equals(role)) {
                        return new Admin(id, username, password);
                    } else {
                        return new Voter(id, username, password, hasVoted);
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public static List<Candidate> getCandidates() {
        List<Candidate> candidates = new ArrayList<>();
        String sql = "SELECT * FROM candidates";
        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                candidates.add(new Candidate(
                        rs.getInt("id"),
                        rs.getString("name"),
                        rs.getString("party"),
                        rs.getInt("votes")
                ));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return candidates;
    }
}

// Voter Panel
class VoterPanel extends JFrame {
    private Voter voter;
    private JRadioButton[] candidateRadios;

    public VoterPanel(Voter voter) {
        this.voter = voter;
        setTitle("Voter Panel - Welcome " + voter.getUsername());
        setSize(500, 300);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);

        JPanel panel = new JPanel(new BorderLayout());
        panel.add(new JLabel("Select your candidate:"), BorderLayout.NORTH);

        JPanel candidatesPanel = new JPanel(new GridLayout(0, 1));
        List<Candidate> candidates = ElectionManager.getCandidates();
        candidateRadios = new JRadioButton[candidates.size()];

        ButtonGroup group = new ButtonGroup();
        for (int i = 0; i < candidates.size(); i++) {
            candidateRadios[i] = new JRadioButton(candidates.get(i).toString());
            group.add(candidateRadios[i]);
            candidatesPanel.add(candidateRadios[i]);
        }

        JScrollPane scrollPane = new JScrollPane(candidatesPanel);
        panel.add(scrollPane, BorderLayout.CENTER);

        JButton btnVote = new JButton("Vote");
        btnVote.setEnabled(!voter.hasVoted());
        btnVote.addActionListener(e -> castVote());

        panel.add(btnVote, BorderLayout.SOUTH);
        add(panel);
    }

    private void castVote() {
        int selectedIndex = -1;
        for (int i = 0; i < candidateRadios.length; i++) {
            if (candidateRadios[i].isSelected()) {
                selectedIndex = i;
                break;
            }
        }

        if (selectedIndex == -1) {
            JOptionPane.showMessageDialog(this, "Please select a candidate!");
            return;
        }

        List<Candidate> candidates = ElectionManager.getCandidates();
        try {
            voter.vote(candidates.get(selectedIndex).getId());
            JOptionPane.showMessageDialog(this, "Vote cast successfully!");
            dispose();
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
        }
    }
}

// Admin Panel
class AdminPanel extends JFrame {
    private JTabbedPane tabbedPane = new JTabbedPane();
    private JTable resultsTable = new JTable();

    public AdminPanel() {
        setTitle("Admin Panel");
        setSize(600, 400);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);

        // Results Tab
        tabbedPane.addTab("View Results", createResultsPanel());
        tabbedPane.addTab("Manage Candidates", createCandidatePanel());
        tabbedPane.addTab("Manage Voters", createVoterPanel());

        add(tabbedPane);
        refreshResults();
    }

    private JPanel createResultsPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        resultsTable.setModel(new DefaultTableModel(
                new Object[]{"ID", "Name", "Party", "Votes"}, 0
        ));
        panel.add(new JScrollPane(resultsTable), BorderLayout.CENTER);
        return panel;
    }

    private JPanel createCandidatePanel() {
        JPanel panel = new JPanel(new GridLayout(0, 2, 5, 5));

        JTextField txtName = new JTextField(20);
        JTextField txtParty = new JTextField(20);
        JButton btnAdd = new JButton("Add Candidate");

        panel.add(new JLabel("Name:"));
        panel.add(txtName);
        panel.add(new JLabel("Party:"));
        panel.add(txtParty);
        panel.add(btnAdd);

        btnAdd.addActionListener(e -> {
            try (Connection conn = DBConnection.getConnection()) {
                String sql = "INSERT INTO candidates (name, party) VALUES (?, ?)";
                PreparedStatement pstmt = conn.prepareStatement(sql);
                pstmt.setString(1, txtName.getText());
                pstmt.setString(2, txtParty.getText());
                pstmt.executeUpdate();
                JOptionPane.showMessageDialog(this, "Candidate added!");
                txtName.setText("");
                txtParty.setText("");
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
            }
        });

        return panel;
    }

    private JPanel createVoterPanel() {
        JPanel panel = new JPanel(new GridLayout(0, 2, 5, 5));

        JTextField txtUser = new JTextField(20);
        JTextField txtPass = new JTextField(20);
        JButton btnAdd = new JButton("Add Voter");

        panel.add(new JLabel("Username:"));
        panel.add(txtUser);
        panel.add(new JLabel("Password:"));
        panel.add(txtPass);
        panel.add(btnAdd);

        btnAdd.addActionListener(e -> {
            try (Connection conn = DBConnection.getConnection()) {
                String sql = "INSERT INTO users (username, password, role) VALUES (?, ?, 'voter')";
                PreparedStatement pstmt = conn.prepareStatement(sql);
                pstmt.setString(1, txtUser.getText());
                pstmt.setString(2, txtPass.getText());
                pstmt.executeUpdate();
                JOptionPane.showMessageDialog(this, "Voter added!");
                txtUser.setText("");
                txtPass.setText("");
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
            }
        });

        return panel;
    }

    private void refreshResults() {
        DefaultTableModel model = (DefaultTableModel) resultsTable.getModel();
        model.setRowCount(0);

        List<Candidate> candidates = ElectionManager.getCandidates();
        for (Candidate c : candidates) {
            model.addRow(new Object[]{c.getId(), c.getName(), c.getParty(), c.getVotes()});
        }
    }
}

// Main Login Window
 class LoginWindow extends JFrame {
    private JTextField txtUsername = new JTextField(20);
    private JPasswordField txtPassword = new JPasswordField(20);
    private JButton btnLogin = new JButton("Login");
    private JButton btnExit = new JButton("Exit");

    public LoginWindow() {
        setTitle("Online Voting System - Login");
        setSize(350, 200);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel(new GridLayout(3, 2, 5, 5));
        panel.add(new JLabel("Username:"));
        panel.add(txtUsername);
        panel.add(new JLabel("Password:"));
        panel.add(txtPassword);
        panel.add(btnLogin);
        panel.add(btnExit);

        add(panel, BorderLayout.CENTER);

        btnLogin.addActionListener(e -> authenticate());
        btnExit.addActionListener(e -> System.exit(0));
    }

    private void authenticate() {
        String username = txtUsername.getText();
        String password = new String(txtPassword.getPassword());

        User user = ElectionManager.authenticate(username, password);
        if (user != null) {
            this.dispose();
            if ("admin".equals(user.getRole())) {
                new AdminPanel().setVisible(true);
            } else {
                new VoterPanel((Voter) user).setVisible(true);
            }
        } else {
            JOptionPane.showMessageDialog(this, "Invalid credentials!");
        }
    }

    public static void main(String[] args) {
        // Initialize database driver
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            JOptionPane.showMessageDialog(null, "MySQL Driver not found!");
            e.printStackTrace();
            System.exit(1);
        }

        SwingUtilities.invokeLater(() -> new LoginWindow().setVisible(true));
    }
}