import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.RoundRectangle2D;

// Main class to run everything
public class MainApp {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            SplashScreen splash = new SplashScreen();
            splash.setVisible(true);
        });
    }
}

// Splash Screen class
class SplashScreen extends JFrame {

    private JLabel animatedLabel;
    private Timer textTimer, fadeTimer;
    private String fullText = "WELCOME TO ONLINE SHOPPING PLATFORM";
    private int charIndex = 0;
    private float opacity = 0.0f;

    public SplashScreen() {
        setUndecorated(true);
        setSize(600, 400);
        setLocationRelativeTo(null);
        setLayout(null);
        getContentPane().setBackground(new Color(0, 0, 0, 0));

        JPanel panel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g;
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(new Color(240, 248, 255, 240));
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 50, 50);
            }
        };
        panel.setLayout(null);
        panel.setBounds(0, 0, 600, 400);
        add(panel);

        // Load and resize logo
        String imagePath = "C:\\Users\\cui\\Downloads\\Logo.jpg";
        ImageIcon logoIcon = new ImageIcon(imagePath);
        Image img = logoIcon.getImage();
        Image resizedImage = img.getScaledInstance(250, 120, Image.SCALE_SMOOTH);
        ImageIcon resizedIcon = new ImageIcon(resizedImage);

        JLabel logoLabel = new JLabel(resizedIcon);
        logoLabel.setBounds(170, 30, 250, 120);
        panel.add(logoLabel);

        animatedLabel = new JLabel("");
        animatedLabel.setFont(new Font("Verdana", Font.BOLD, 20));
        animatedLabel.setBounds(50, 170, 500, 50);
        animatedLabel.setHorizontalAlignment(SwingConstants.CENTER);
        animatedLabel.setForeground(new Color(0, 102, 204));
        panel.add(animatedLabel);

        setShape(new RoundRectangle2D.Double(0, 0, getWidth(), getHeight(), 50, 50));
        fadeIn();
    }

    private void fadeIn() {
        fadeTimer = new Timer(50, e -> {
            opacity += 0.05f;
            if (opacity >= 1.0f) {
                opacity = 1.0f;
                fadeTimer.stop();
                startTextAnimation();
            }
            setOpacity(opacity);
        });
        fadeTimer.start();
    }

    private void startTextAnimation() {
        textTimer = new Timer(100, e -> {
            if (charIndex < fullText.length()) {
                animatedLabel.setText(animatedLabel.getText() + fullText.charAt(charIndex));
                charIndex++;
            } else {
                textTimer.stop();
                launchMainScreen();
            }
        });
        textTimer.start();
    }

    private void launchMainScreen() {
        dispose();
        new HomeGUI().setVisible(true);
    }
}

// Home Screen class

class HomeGUI extends JFrame implements ActionListener {

    private JButton button1, button2, button3, button4, custLoginBtn, adminLoginBtn, closeWindowBtn;

    public HomeGUI() {
        setTitle("ShopOnline - E-Commerce Platform");
        setSize(550, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null); // Center the window

        JPanel panel = new JPanel();
        panel.setLayout(null);
        panel.setBackground(new Color(240, 248, 255));  // Light sky blue background
        add(panel);

        // Load and resize logo
        String imagePath = "C:\\Users\\cui\\Downloads\\Logo.jpg"; // Update path accordingly
        ImageIcon logoIcon = new ImageIcon(imagePath);
        Image img = logoIcon.getImage();
        Image resizedImage = img.getScaledInstance(200, 100, Image.SCALE_SMOOTH);
        ImageIcon resizedIcon = new ImageIcon(resizedImage);

        JLabel imageLabel = new JLabel(resizedIcon);
        imageLabel.setBounds(170, 10, 200, 100);
        panel.add(imageLabel);

        closeWindowBtn = createButton("Close", 430, 20, 80, 30, panel, new Color(220, 20, 60), Color.WHITE);
        closeWindowBtn.addActionListener(this);

        // Welcome TextField
        JTextField welcomeField = new JTextField("Welcome to Online Shopping Store");
        welcomeField.setBounds(100, 130, 330, 40);
        welcomeField.setHorizontalAlignment(JTextField.CENTER);
        welcomeField.setEditable(false);
        welcomeField.setFont(new Font("Verdana", Font.BOLD, 16));
        welcomeField.setBackground(new Color(255, 228, 196));  // bisque color
        panel.add(welcomeField);

        // Buttons with color combinations
        button1 = createButton("Customer Registration", 130, 190, 280, 35, panel, new Color(70, 130, 180), Color.WHITE);
        button2 = createButton("Administrator Registration", 130, 240, 280, 35, panel, new Color(100, 149, 237), Color.WHITE);
        button3 = createButton("Customer Password Change", 130, 290, 280, 35, panel, new Color(60, 179, 113), Color.WHITE);
        button4 = createButton("Administrator Password Change", 130, 340, 280, 35, panel, new Color(255, 140, 0), Color.WHITE);
        custLoginBtn = createButton("Customer Login", 160, 390, 220, 35, panel, new Color(255, 165, 0), Color.BLACK);
        adminLoginBtn = createButton("Administrator Login", 160, 440, 220, 35, panel, new Color(138, 43, 226), Color.WHITE);

        // Register single listener
        button1.addActionListener(this);
        button2.addActionListener(this);
        button3.addActionListener(this);
        button4.addActionListener(this);
        custLoginBtn.addActionListener(this);
        adminLoginBtn.addActionListener(this);
    }

    private JButton createButton(String text, int x, int y, int width, int height, JPanel panel, Color bgColor, Color fgColor) {
        JButton button = new JButton(text);
        button.setBounds(x, y, width, height);
        button.setBackground(bgColor);
        button.setForeground(fgColor);
        button.setFocusPainted(false);
        button.setFont(new Font("Tahoma", Font.BOLD, 14));
        panel.add(button);
        return button;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        Object source = e.getSource();
        if (source == button1) {
            System.out.println("Button1 Pressed...Opening Customer Registration");
            new CustGUI();
        } else if (source == button2) {
            System.out.println("Button2 Pressed...Opening Admin Registration");
            new AdminGUI();
        } else if (source == button3) {
            System.out.println("Button3 Pressed...Opening Customer Password Change");
            new CustomerPasswordChange();
        } else if (source == button4) {
            System.out.println("Button4 Pressed...Opening Admin Password Change");
            new AdminPasswordChange();
        } else if (source == custLoginBtn) {
            System.out.println("custLoginBtn Pressed...Opening Customer Login");
            new CustLogin();
        } else if (source == adminLoginBtn) {
            System.out.println("adminLoginBtn Pressed...Opening Admin Login");
            new AdminLogin();
        } else if (source == closeWindowBtn) {
            dispose();
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            HomeGUI homeGUI = new HomeGUI();
            homeGUI.setVisible(true);
        });
    }
}
